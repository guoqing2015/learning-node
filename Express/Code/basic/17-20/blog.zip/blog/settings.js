/**
 * Created with JetBrains WebStorm.
 * User: Administrator
 * Date: 12-9-25
 * Time: 上午9:58
 * To change this template use File | Settings | File Templates.
 */
module.exports={
    cookieSecret:"blog",
    db:"blog",
    host:"localhost"
}