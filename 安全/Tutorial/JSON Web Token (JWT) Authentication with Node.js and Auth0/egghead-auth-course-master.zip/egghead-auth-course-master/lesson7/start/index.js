const API_URL = "";
const AUTH_URL = "";

let ACCESS_TOKEN;

const headlineBtn = document.querySelector("#headline");
const secretBtn = document.querySelector("#secret");
const loginBtn = document.querySelector("#loginBtn");
const logoutBtn = document.querySelector("#logoutBtn");

headlineBtn.addEventListener("click", () => {

});

secretBtn.addEventListener("click", (event) => {

});

logoutBtn.addEventListener("click", (event) => {

});

loginBtn.addEventListener("click", (event) => {

});